using System.Collections.Generic;
using System.Threading.Tasks;
using api.Domain.Models;
using api.Domain.Repositories;
using api.Domain.Services;
using api.Domain.Services.Communication;
using System;


namespace api.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;
	    private readonly IUnitOfWork _unitOfWork;

        public OrderService(IOrderRepository orderRepository, IUnitOfWork unitOfWork)
        {
            this._orderRepository = orderRepository;
            this._unitOfWork = unitOfWork;

        }

        public async Task<IEnumerable<Order>> ListAsync()
        { 
            return await _orderRepository.ListAsync();
        }
        public async Task<OrderResponse> SaveAsync(Order order)
        {
            try
            {
                await _orderRepository.AddAsync(order);
                await _unitOfWork.CompleteAsync();
                
                return new OrderResponse(order);
            }
            catch (Exception ex)
            {
                return new OrderResponse($"An error occurred when saving the order: {ex.Message}");
            }
        }
        public async Task<OrderResponse> UpdateAsync(int id, Order order)
        {
            var existingOrder = await _orderRepository.FindByIdAsync(id);

            if (existingOrder == null)
                return new OrderResponse("Order not found.");

            existingOrder.CustomerName = order.CustomerName;

            try
            {
                _orderRepository.Update(existingOrder);
                await _unitOfWork.CompleteAsync();

                return new OrderResponse(existingOrder);
            }
            catch (Exception ex)
            {
                return new OrderResponse($"An error occurred when updating the order: {ex.Message}");
            }
        }
        public async Task<OrderResponse> DeleteAsync(int id)
        {
            var existingOrder = await _orderRepository.FindByIdAsync(id);

            if (existingOrder == null)
                return new OrderResponse("Order not found.");

            try
            {
                _orderRepository.Remove(existingOrder);
                await _unitOfWork.CompleteAsync();

                return new OrderResponse(existingOrder);
            }
            catch (Exception ex)
            {
                return new OrderResponse($"An error occurred when deleting the order: {ex.Message}");
            }
        }
        public async Task<IEnumerable<Order>> ListAsync(string customerName)
        { 
            return await _orderRepository.ListAsync(customerName);
        }
    }
}
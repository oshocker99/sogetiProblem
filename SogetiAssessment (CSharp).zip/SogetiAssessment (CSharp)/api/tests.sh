# I decided to use a new form of testing to demonstrate my range of ability. the java code used mock, I used selenium in C# for UI testing
# at maverick, and here we ping the endpoints and retreive their results.

#If these have trouble, I have attached a postman collection with all of the relevant tests, make sure to do $ dotnet run before expecting results.

# get all orders test
curl -v http://localhost:5000/api/orders


# POST an order test
curl -v -X POST -H "Content-Type: application/json" -d '{"customerName": "Luke Skywalker"}' http://localhost:5000/api/orders


# PUT an order test

curl -v -X PUT -H "Content-Type: application/json" -d '{"customerName":"Bobby"}' http://localhost:5000/api/orders/102

# get all orders by a customer tests
curl -v http://localhost:5000/api/orders/Bobby 

# DELETE an order by id
curl -v -X DELETE http://localhost:5000/api/orders/102
using Microsoft.EntityFrameworkCore;
using api.Domain.Models;

namespace api.Persistence.Contexts
{
    public class AppDbContext : DbContext
    {
        public DbSet<Order> Orders { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            
            builder.Entity<Order>().ToTable("Orders");
            builder.Entity<Order>().HasKey(p => p.Id);
            builder.Entity<Order>().Property(p => p.Id).IsRequired().ValueGeneratedOnAdd();
            builder.Entity<Order>().Property(p => p.CustomerName).IsRequired().HasMaxLength(30);

            builder.Entity<Order>().HasData
            (
                new Order { Id = 100, CustomerName = "Owen Schacher" }, // Id set manually due to in-memory provider
                new Order { Id = 101, CustomerName = "Foo Bar" }
            );
        }
    }
}
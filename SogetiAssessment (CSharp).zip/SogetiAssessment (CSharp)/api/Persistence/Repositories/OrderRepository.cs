using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using api.Domain.Models;
using api.Domain.Repositories;
using api.Persistence.Contexts;
using System.Linq;

namespace api.Persistence.Repositories
{
    public class OrderRepository : BaseRepository, IOrderRepository
    {
        public OrderRepository(AppDbContext context) : base(context)
        {
        }

        public async Task<IEnumerable<Order>> ListAsync()
        {
            return await _context.Orders.ToListAsync();
        }
        public async Task AddAsync(Order order)
        {
            await _context.Orders.AddAsync(order);
        }
        public async Task<Order> FindByIdAsync(int id)
        {
            return await _context.Orders.FindAsync(id);
        }

        public void Update(Order order)
        {
            _context.Orders.Update(order);
        }
        public void Remove(Order order)
        {
            _context.Orders.Remove(order);
        }
        public async Task<IEnumerable<Order>> ListAsync(string customerName)
        {   
            var orders = from o in _context.Orders
                        where o.CustomerName == customerName
                        select o;
            return await orders.ToListAsync();
        }
    }
}
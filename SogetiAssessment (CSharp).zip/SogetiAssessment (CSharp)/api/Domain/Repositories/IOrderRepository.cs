using System.Collections.Generic;
using System.Threading.Tasks;
using api.Domain.Models;

namespace api.Domain.Repositories
{
    public interface IOrderRepository
    {
        Task<IEnumerable<Order>> ListAsync();
        Task AddAsync(Order order);
        Task<Order> FindByIdAsync(int id);
	    void Update(Order order);
        void Remove(Order order);
        Task<IEnumerable<Order>> ListAsync(string customerName);

    }

}
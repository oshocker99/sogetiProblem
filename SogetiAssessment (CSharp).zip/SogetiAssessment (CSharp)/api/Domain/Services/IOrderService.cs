using System.Collections.Generic;
using System.Threading.Tasks;
using api.Domain.Models;
using api.Domain.Services.Communication;

namespace api.Domain.Services
{
    public interface IOrderService
    {
        Task<IEnumerable<Order>> ListAsync();
        Task<OrderResponse> SaveAsync(Order order);
        Task<OrderResponse> UpdateAsync(int id, Order category);
        Task<OrderResponse> DeleteAsync(int id);

        Task<IEnumerable<Order>> ListAsync(string customerName);
    
    }
}
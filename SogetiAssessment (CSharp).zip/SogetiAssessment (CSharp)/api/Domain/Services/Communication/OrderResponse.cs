using api.Domain.Models;

namespace api.Domain.Services.Communication
{
    public class OrderResponse : BaseResponse
    {
        public Order order { get; private set; }

        private OrderResponse(bool success, string message, Order order) : base(success, message)
        {
            this.order = order;
        }

        /// <summary>
        /// Creates a success response.
        /// </summary>
        /// <param name="order">Saved order.</param>
        /// <returns>Response.</returns>
        public OrderResponse(Order order) : this(true, string.Empty, order)
        { }

        /// <summary>
        /// Creates am error response.
        /// </summary>
        /// <param name="message">Error message.</param>
        /// <returns>Response.</returns>
        public OrderResponse(string message) : this(false, message, null)
        { }
    }
}
using System.Collections.Generic;

namespace api.Domain.Models
{
    public class Order
    {
        public int Id { get; set; }
        //Who made order
        public string CustomerName { get; set; }
        
    }
}
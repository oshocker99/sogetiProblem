using System.ComponentModel.DataAnnotations;

namespace api.Resources
{
    public class SaveOrderResource
    {
        [Required]
        [MaxLength(30)]
        public string CustomerName { get; set; }
    }
}
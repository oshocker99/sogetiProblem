namespace api.Resources
{
    public class OrderResource
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
    }
}
package com.ordersRestService.RestApp;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;

import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;

import static org.mockito.Mockito.*;
@ExtendWith(SpringExtension.class)
@WebMvcTest(OrderController.class)
public class OrderControllerIntTest {
	
	@Autowired
	private MockMvc mvc;
	
	@MockBean
	private OrderService orderService;
	
	@Test
	void getOrdersByCustomerTest() throws Exception {
		
		//mock the data
		
		String customer = "Owen";
		String item = "apples";
		Integer price = 3;
		
		Order order = new Order(customer, item, price);
		
		
		
		when(orderService.getOrder(customer)).thenReturn(order);
		//make request
		RequestBuilder request = MockMvcRequestBuilders.get("/orders/"+customer);
		
		mvc.perform(request)
				.andExpect(MockMvcResultMatchers.jsonPath("$.customer").value(customer))
				.andExpect(MockMvcResultMatchers.jsonPath("$.item").value(item))
				.andExpect(MockMvcResultMatchers.jsonPath("$.price").value(price))
				.andExpect(MockMvcResultMatchers.status().isOk());
		
	}
	
	@Test
	void addNewOrderTest() throws Exception{
		//mock data
		
		String customer = "Owen";
		String item = "apples";
		Integer price = 3;
		
		Order order = new Order(customer, item, price);
		
		when(orderService.addOrder(any(Order.class))).thenReturn(order);
		
		//make request
		RequestBuilder request = MockMvcRequestBuilders.post("/orders/post")
				.content(new ObjectMapper().writeValueAsString(order))
				.contentType(MediaType.APPLICATION_JSON);

		mvc.perform(request)
			.andExpect(MockMvcResultMatchers.status().isCreated())
			.andExpect(MockMvcResultMatchers.jsonPath("$.customer").value(customer))
			.andExpect(MockMvcResultMatchers.jsonPath("$.item").value(item))
			.andExpect(MockMvcResultMatchers.jsonPath("$.price").value(price));
		
	}
	
	@Test
	void deleteOrderTest() throws Exception{
		//mock data
		
				String customer = "Owen";
				String item = "apples";
				Integer price = 3;
				
				Order order = new Order(customer, item, price);
				orderService.addOrder(order);
			
				
				when(orderService.addOrder(any(Order.class))).thenReturn(order);
				
				//make add request
				RequestBuilder request = MockMvcRequestBuilders.post("/orders/post")
						.content(new ObjectMapper().writeValueAsString(order))
						.contentType(MediaType.APPLICATION_JSON);
				
				mvc.perform(request);
				when(orderService.removeOrder(any(Order.class))).thenReturn(true);
				
				//make delete request
				request = MockMvcRequestBuilders.delete("/orders/delete")
				.content(new ObjectMapper().writeValueAsString(order))
				.contentType(MediaType.APPLICATION_JSON);
				
				mvc.perform(request)
				.andExpect(MockMvcResultMatchers.status().isOk());
	}
	
	@Test
	void updateOrderTest() throws Exception{
		//mock data
		
		String customer = "Owen";
		String item = "apples";
		Integer price = 3;
		
		Order order = new Order(customer, item, price);
		orderService.addOrder(order);
	
		
		when(orderService.addOrder(any(Order.class))).thenReturn(order);
		
		//make add request
		RequestBuilder request = MockMvcRequestBuilders.post("/orders/post")
				.content(new ObjectMapper().writeValueAsString(order))
				.contentType(MediaType.APPLICATION_JSON);
		mvc.perform(request);
		
		
		//make delete request
		when(orderService.removeOrder(any(Order.class))).thenReturn(true);

		order.setPrice(5);
		when(orderService.addOrder(any(Order.class))).thenReturn(order);
		when(orderService.getOrder(customer)).thenReturn(order);

		request = MockMvcRequestBuilders.put("/orders/update")
		.content(new ObjectMapper().writeValueAsString(order))
		.contentType(MediaType.APPLICATION_JSON);
		
		mvc.perform(request)
		.andExpect(MockMvcResultMatchers.status().isOk());
	}
}

package com.ordersRestService.RestApp;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/*
 * This class over sees the endpoint calls for the application
 */
@RestController
@RequestMapping("/orders")
public class OrderController {
	@Autowired
	private OrderService os = new OrderService();
	
	@PostMapping(path = "/post")
	public ResponseEntity<Order> addNewOrder(@RequestBody Order order) {
		return new ResponseEntity<>(os.addOrder(order), HttpStatus.CREATED);
	}
	
	@GetMapping(path = "/{customer}")
	public ResponseEntity<Order> ordersByCustomer(@PathVariable String customer) {
		return new ResponseEntity<>(os.getOrder(customer), HttpStatus.OK);
	}
	
	@PutMapping(path = "/update")
	public ResponseEntity<String> updateOrder(@RequestBody Order newOrder){
		
		if(os.removeOrder(os.getOrder(newOrder.getCustomer()))) {
			os.addOrder(newOrder);
			return new ResponseEntity<>(HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping(path = "/delete")
	public ResponseEntity<String> deleteOrder(@RequestBody Order order) {
		if(os.removeOrder(order)) {
			return new ResponseEntity<>(HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}

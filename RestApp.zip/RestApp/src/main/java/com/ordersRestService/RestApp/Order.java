package com.ordersRestService.RestApp;


public class Order {
	private String customer;
	private String item;
	private Integer price;
	
	public Order(String customer, String items, Integer price) {
		this.setCustomer(customer);
		this.setItem(items);
		this.setPrice(price);
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}


}

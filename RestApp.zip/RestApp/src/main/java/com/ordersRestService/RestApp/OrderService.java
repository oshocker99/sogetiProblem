package com.ordersRestService.RestApp;

import java.util.ArrayList;
import java.util.List;


/*
 * This service keeps track of the orders and has helper methods for traversing the orders
 */
public class OrderService {
	private List<Order> orders;
	
	public OrderService() {
		this.orders = new ArrayList<Order>();
	}
	public List<Order> getOrders(){
		return this.orders;
	}
	public Order getOrder(String customer){ 	
		for (Order order : this.orders) {
			if(order.getCustomer() == customer){
				return order;
			}
		}
		return null;
	}
	public Order addOrder(Order o) {
		orders.add(o);
		return o;
	}
	public Boolean removeOrder(Order o) {
		return orders.remove(o);
	}
	
}
